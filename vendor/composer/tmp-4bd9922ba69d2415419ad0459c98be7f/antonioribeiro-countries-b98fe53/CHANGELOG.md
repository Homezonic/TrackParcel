# Changelog

## 0.7.0 - 2019-09-19
### Updated
- Strings, arrays and collection helpers
### Removed 
- PHP 7.0 support

## 0.6.0 - 2018-08-19
### Fixed
- flag-icon tag
### Changed 
- Countries service directory

## 0.5.7 - 2018-03-13
### Fixed
- Missing Exception class

## 0.5.5 - 2018-02-17
### Changed
- Removed hard coded cache set to 10 minutes

## 0.5.0 - 2018-01-22
### Changed
- Package is now PHP agnostic
- Laravel version is now pragmarx/countries-laravel

## 0.1.0 - 2017-02-13
### Added
- First version

## 0.1.1 - 2017-03-07
### Added
- Validation rules
- Language filtering
- Currency filtering
- Dynamic where calls
